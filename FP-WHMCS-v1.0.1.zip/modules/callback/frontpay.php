<?php


require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';
logActivity('/gateways/callback/frontpay.php: In Callback File!', 0);

$gatewayModuleName = basename(__FILE__, '.php');

$gatewayParams = getGatewayVariables($gatewayModuleName);

$mid = $gatewayParams['accountId'];
$mpw = $gatewayParams['password'];
$order_info = $_GET['transaction_reference'];
$transactionID = $_GET['tpaycode'];
$tcode = $_GET['tcode'];
$key = $_GET['key'];
$orderID = $_GET['transaction_reference'];









//Curl Request

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://portal.frontpay.pk/api/get-order-detail',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('transaction_reference' => $orderID,'fp_merchant_id' => $mid,'fp_merchant_secret' => $mpw),
));

$result = curl_exec($curl);

curl_close($curl);
// Submit the GET request

$res = json_decode($result, true);




logActivity('/gateways/callback/frontpay.php: Curl Request Executed Successfully!', 0);

if (curl_errno($ch)) {  //catch if curl error exists and show it
        logActivity('/gateways/callback/frontpay.php: Curl Request Failed!', 0);
        echo 'Curl error: ' . curl_error($ch);
    } else {


        // Close cURL session handle
        curl_close($ch);
        if ($res['status'] != 1) {
            logActivity('/gateways/callback/frontpay.php: Invalid FrontPay ID provided!', 0);

            echo 'status 01';
        } else {
            
            $detail = $res['detail'];
            logActivity('/gateways/callback/frontpay.php: Curl Request Response Success!', 0);

        
            if ($res['status'] == 1) {
                if ($detail['transaction_status'] == "COMPLETE") {
                    logActivity('/gateways/callback/frontpay.php: If Order Status Is PAID! Invoice #' . $orderID, 0);


                    // $updatedUserCount = Capsule::table('tblinvoices')
                    //     ->where('id', '184');
                    $table = "tblinvoices";
                    $fields = "id,subtotal";
                    $where = array("id" => $orderID);
                    $result = select_query($table, $fields, $where);
                    $data = mysql_fetch_array($result);


                    addInvoicePayment(
                        $orderID,
                        $transactionID,
                        $data['subtotal'],
                        '',
                        'FrontPay'
                    );
                    header('Location: ' . App::getSystemUrl() . 'viewinvoice.php?id=' . $orderID);
                } elseif ($detail['transaction_status'] == "DROPPED") {
                    logActivity('/gateways/callback/frontpay.php: If Order Status Is DROPPED! Invoice #' . $orderID, 0);

                    header('Location: ' . App::getSystemUrl() . 'viewinvoice.php?id=' . $orderID);
                }
                elseif ($detail['transaction_status'] == "PENDING") {
                    logActivity('/gateways/callback/frontpay.php: If Order Status Is PENDING! Invoice #' . $orderID, 0);

                    header('Location: ' . App::getSystemUrl() . 'viewinvoice.php?id=' . $orderID);
                } elseif ($detail['transaction_status'] == "FAILED") {
                    
                    logActivity('/gateways/callback/frontpay.php: If Order Status Is FAILED! Invoice #' . $orderID, 0);

                    header('Location: ' . App::getSystemUrl() . 'viewinvoice.php?id=' . $orderID);
                }
            }
        }
    }

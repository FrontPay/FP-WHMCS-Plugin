<?php

use Illuminate\Support\Facades\Redirect;

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function frontpay_MetaData()
{   
    return array(
        'DisplayName' => 'FrontPay',
        'APIVersion' => 'FrontPay-WHMCS-v1.0.1', //Version 
        'DisableLocalCreditCardInput' => true,
        'TokenisedStorage' => false,
    );
}

function frontpay_config()
{
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'FrontPay',
        ),
        'accountId' => array(
            'FriendlyName' => 'FP Merchant ID',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
        ),
        'password' => array(
            'FriendlyName' => 'Fp Secret ID',
            'Type' => 'password',
            'Size' => '250',
            'Default' => '',
        ),


        'testMode' => array(
            'FriendlyName' => 'Test Mode',
            'Type' => 'yesno',
            'Description' => 'Tick to enable Test mode',
        ),

    );
}


function frontpay_link($params)
{

    $dt = new DateTime();
    $dt->setTimezone(new DateTimeZone('Asia/Karachi'));
    $dt->setTimestamp(time());

    $accountId = $params['accountId'];
    $password = $params['password'];
    $secretword = $params['secretword'];
    $testMode = $params['testMode'];
    $timelimit = $params['timelimit'];
    $date = $dt->format('d/m/y');




    // Invoice Parameters
    $invoiceId = $params['invoiceid'];
    $description = $params["description"];
    $amount = $params['amount'];
    $currencyCode = $params['currency'];

    // Client Parameters
    $firstname = $params['clientdetails']['firstname'];
    $lastname = $params['clientdetails']['lastname'];
    $email = $params['clientdetails']['email'];
    $address1 = $params['clientdetails']['address1'];
    $address2 = $params['clientdetails']['address2'];
    $city = $params['clientdetails']['city'];
    $state = $params['clientdetails']['state'];
    $postcode = $params['clientdetails']['postcode'];
    $country = $params['clientdetails']['country'];
    $phone = $params['clientdetails']['phonenumber'];

    // System Parameters
    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $returnUrl = $params['returnurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];

    $url = 'https://portal.frontpay.pk/api/secureform';

    $postfields = array();
    $postfields['mid'] = $accountId;
    $postfields['mpw'] = $password;
    $postfields['is_encrypted'] = 0;
    $postfields['currency_code'] = $currencyCode;
    $postfields['cartTotal'] = $amount;
    $postfields['paypro_order_id'] = time() . '-' . $invoiceId;
    $postfields['merchant_order_id'] = $invoiceId;
    $postfields['first_name'] = $firstname;
    $postfields['last_name'] = $lastname;
    $postfields['street_address'] = $address1;
    $postfields['city'] = $city;
    $postfields['request_from'] = 'whmcs';
    $postfields['store_currency'] = $currencyCode;
    $postfields['state'] = $state;
    $postfields['zip'] = $postcode;
    $postfields['country'] = $country;
    $postfields['email'] = $email;
    $postfields['secret_public'] = base64_encode($secretword);
    $postfields['timeout'] = $timelimit * 60;
    $postfields['phone'] = '0' . ltrim(str_replace(array('+92', '(', ')', '-'), array('0', '', '', ''), $phone), "0");
    $postfields['ship_street_address'] = $address1;
    $postfields['ship_city'] = $city;
    $postfields['ship_state'] = $state;
    $postfields['ship_zip'] = $postcode;
    $postfields['ship_country'] = $country;
    $postfields['lang'] = $langPayNow;
    $postfields['return_url'] = $systemUrl . '/modules/gateways/callback/' . $moduleName . '.php';
    $postfields['request_site_checkout_url'] = $systemUrl . '';
    $postfields['request_is_valid'] = true;
    $postfields['merchant_name'] = $params["accountId"];
    $postfields['issueDate'] = $dt->format('d/m/y');
    $postfields['mode'] = $testMode == 'on' ? 'yes' : 'no';

    $billDetails = array();
    $postfields['cartItemList'] =   urlencode(json_encode($billDetails));;

    $htmlOutput = '<form method="get" action="' . $url . '"> ';
    foreach ($postfields as $k => $v) {
        $htmlOutput .= '<input type="hidden" name="' . $k . '" value="' . $v . '" />';
    }

    if (isset($_GET['id'])) {
        $htmlOutput .= '<input type="submit" value="' . $langPayNow . '" />';
    }

    $htmlOutput .= '</form>';

    logActivity('/gateways/paypro.php: Form Created Successfully!', 0);
    return $htmlOutput;
}
